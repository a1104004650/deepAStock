# CHANGELOG — deepAStock 深度A股交易

> 版本日志按时间倒序。`v1.0.0` 为首次发布版本。

## v1.1.4 (2026-09-14) — RSS 订阅管理全面重构

### 增强（当轮追加）
- **删除 RSSHub 公网订阅类型**：订阅仅保留「HTTP/HTTPS 直连」与「RSSHub 本地 Docker」，已移除全部公网实例（`rsshub.app`）订阅源及默认种子，存量数据一并清除。
- **消息时间统一（东八区 · 24 小时制）**：大盘「消息滚动」与「订阅」消息流时间解析统一：平台新闻 epoch 秒、RSS 各类带/不带时区的时间全部换算为北京时间；当天显示 `HH:mm`，跨日显示 `MM-DD HH:mm`。
- **消息倒序（最新在上）**：大盘消息滚动与订阅消息流均按发布时间倒序（最新消息置顶）。
- **单源独立轮询**：订阅源表格每行新增「轮询」按钮，可忽略间隔立即抓取单个源。
- **本地 RSSHub 自动拼前缀**：本地类型只需填 `/jin10/index` 后缀，保存/测试自动拼 `http://127.0.0.1:11200`。
- **默认订阅源梳理为炒股 / IT / 科技主题**：移除泛资讯的「知乎日报」与全部公网源，补入炒股相关金十快讯、财联社深度。
- **消息流滤镜调整**：移除「含ST」开关；重要度下拉增加「全部」选项（大盘看板同步增加「全部」分类）。
- **消息清理与 2 万条上限**：新增「清空消息」按钮；`rss_items` 全局上限 20000 条，超限自动删除最旧数据。

### 订阅源新字段（替换旧 平台+路径+秒 体系）
- **名称 / 关注标签(自定义数组) / 备注 / RSS类型 / 订阅地址 / 轮询时间(分钟, 默认5) / 启用状态 / 网络状态** 八项。
- **RSS类型仅两类**：`HTTP/HTTPS 直连`（如 `https://www.ithome.com/rss/`、`https://xueqiu.com/hots/topic/rss`）；`RSSHub`（分 **公网** 与 **本地 Docker** 两种，如 `https://rsshub.app/36kr/newsflashes` / `http://127.0.0.1:11200/cls/telegraph`）。
- **订阅地址直接写 URL，不做任何校验**（原「平台 → 自动拼接路径」逻辑全部移除，`filter_st` 字段一并删除）。
- 页面粘贴了 RSSHub 官方路由文档链接：`https://rsshub-doc.pages.dev/traditional-media.html#cai-xin-wang`。
- **点击「测试」按 RSSHub 类型测网络**并写回订阅源 `网络状态` 字段（`untested` / `ok:N` / `err:...`）；「订阅消息」页每行有独立测试按钮。

### 轮询与通知
- 轮询按**分钟**限频（默认 5 分钟），调度仍 30 秒级；**每个订阅源独立短事务提交**，消除 SQLite `database is locked` 并发写锁。
- **所有轮询增量数据都进全局通知**：前端每 60 秒轮询后端 `recent` 增量队列，逐条弹出渐变通知（原只提示 `importance==1`），本地去重。
- **部署即自带默认订阅源**（雪球 / IT之家 / 爱范儿 / 钛媒体 直连 + 36氪 / 财联社 / 华尔街见闻 / 知乎日报 / 财新 RSSHub 公网与本地各一份），初始化建表后自动写入。

### 变更
- 旧数据库 `rss_sources` / `rss_items` 表结构与字段不兼容，启动时自动 **DROP 重建**并 seed 默认源（旧数据清空，符合重构预期）。
- 「设置 → RSSHub 订阅」同步新字段；微博 Cookie 仅 `weibo/user/{uid}` 直连路由需要，保留在设置页。

## v1.1.4 (2026-09-11) — 本机一键启动 + 微博 Cookie 移到应用内配置

### 新增功能
- **`start.bat` 一键本地启动前后端（无需 Docker）**：后端从 8000、前端从 5173 起自动寻找空闲端口（冲突自动顺延），`Ctrl+C` 一并停止；不再需要原来的菜单式启动器。
- **微博订阅 Cookie 不再写进 docker/环境变量**：新增「设置 → RSSHub 订阅」和「订阅消息 → RSSHub 配置」的**微博 Cookie** 输入框，保存在应用自身配置中；微博用户订阅（`/weibo/user/{uid}`）由后端**直连 `m.weibo.cn`** 拉取（带 Cookie、解析图片/转发/时间），完全不依赖 RSSHub 的 `WEIBO_COOKIES`；Cookie 失效时轮询状态给出明确提示。

### 变更
- 移除 `docker-compose.yml` 中 RSSHub 的 `WEIBO_COOKIES` 注释占位。
- 前端 vite 代理目标改为读取 `BACKEND_PORT` 环境变量，跟随一键启动选出的后端端口。

## v1.1.3 (2026-09-11) — RSSHub 可访问性修复 + 微博订阅配置指引

### 修复
- **RSSHub 仅监听 127.0.0.1，宿主机 11200 端口一直打不开**：compose 中 `LISTEN_INADDR_ANY=0`（已改为 `true` 并重建容器）。自检：`docker exec deepastock-rsshub cat /proc/net/tcp` 无 `0100007F:04B0` 行、`docker port deepastock-rsshub` 显示 `0.0.0.0:11200`。

### 使用须知（微博订阅）
- 微博**个人博主 / 热搜**类路由在 RSSHub 中标记 `requirePuppeteer`：未提供 Cookie 时返回 `Cooling down before new visitor Cookies from https://m.weibo.cn/ may be fetched`（503）。
- 正确姿势：登录 `https://m.weibo.cn` → F12 → 复制任一 `m.weibo.cn` 请求的 **Cookie 请求头整串** → 填入 `docker-compose.yml` rsshub 服务的 `WEIBO_COOKIES`（已预留注释位）→ `docker compose up -d rsshub` 重建 → 测试 `http://127.0.0.1:11200/weibo/user/{uid}`。
- 「设置 → RSSHub 订阅」与「订阅消息」页均已补充该配置提示。

## v1.1.2 (2026-09-11) — 实盘导入支持券商交割单

### 新增功能
- **实盘导入直接解析券商交割单**（CSV/Excel）：
  - **同花顺 / 东方财富 / 同花顺投资账本 / 各券商**导出的交割单，表头别名自动识别（成交日期、证券代码、买卖标志、成交数量、成交价格、成交金额、手续费、印花税、过户费、收付金额…）；
  - 编码自动识别（UTF-8 / GBK 等），**Excel .xlsx/.xls 直接支持**（含标题行、汇总行、日期序列号处理）；