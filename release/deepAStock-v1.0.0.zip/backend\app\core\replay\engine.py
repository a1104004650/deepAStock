"""复盘引擎 - 每日盘后生成复盘报告"""
from datetime import date, timedelta
import json
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.market.quote_service import MarketService
from app.core.datasource.manager import DataSourceManager
from app.core.agent.base import AgentContext
from app.core.agent.executor import AgentExecutor
from app.models.market import ReplayReport, LimitUp
from app.utils.logger import logger


class ReplayEngine:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.market = MarketService(db)
        self.executor = AgentExecutor(db)

    async def run(self, target_date: date = None) -> dict:
        target_date = target_date or date.today()
        logger.info(f"=== 开始复盘 {target_date} ===")

        # 数据采集
        indices = await self.market.get_indices()
        sector_flow = await self.market.get_sector_money_flow()
        limit_up = await self.market.get_limit_up()
        ladder = await self.market.get_limit_up_ladder()
        dragon_tiger = await self.market.get_dragon_tiger()
        distribution = await self.market.get_market_distribution()
        news = await self.market.get_news(20)

        market_summary = {
            "date": target_date.isoformat(),
            "indices": indices[:4],
            "distribution": distribution,
            "limit_up_count": len(limit_up),
            "news": news[:5],
        }

        # 三智能体复盘
        ctx = AgentContext(
            date=target_date.isoformat(),
            market_data={
                "sector_flow": sector_flow,
                "limit_up": limit_up,
                "limit_ladder": ladder,
                "distribution": distribution,
                "news": news,
                "dragon_tiger": dragon_tiger,
            },
        )
        reviews = {}
        for at in ["research", "short_term", "swing"]:
            try:
                result = await self.executor.run(agent_type=at, task="daily_replay", context=ctx)
                reviews[at] = result.model_dump()
            except Exception as e:
                logger.warning(f"agent {at} replay failed: {e}")
                reviews[at] = {"summary": f"复盘失败: {e}", "agent_type": at}

        # 生成次日选股池（基于涨停股 + 板块龙头）
        stock_pool = self._build_stock_pool(limit_up, sector_flow)
        stock_pool = await self._enrich_stock_pool(stock_pool)

        # 组装报告
        report = ReplayReport(
            date=target_date,
            market_summary=market_summary,
            sector_flow=sector_flow,
            limit_analysis={"ladder": ladder, "dragon_tiger": dragon_tiger},
            stock_pool=stock_pool,
            agent_reviews=reviews,
            report_md=self._to_markdown(target_date, market_summary, sector_flow, ladder, stock_pool, reviews),
        )
        existing = (await self.db.execute(select(ReplayReport).where(ReplayReport.date == target_date))).scalars().first()
        if existing:
            existing.market_summary = report.market_summary
            existing.sector_flow = report.sector_flow
            existing.limit_analysis = report.limit_analysis
            existing.stock_pool = report.stock_pool
            existing.agent_reviews = report.agent_reviews
            existing.report_md = report.report_md
            existing.report_html = report.report_html
            report = existing
        else:
            self.db.add(report)
        await self.db.commit()

        logger.info(f"=== 复盘完成 {target_date}, 选股池 {len(stock_pool)} 只 ===")
        return {"status": "success", "date": target_date.isoformat(), "report_id": report.id,
                "stock_pool": stock_pool, "reviews": reviews}

    def _build_stock_pool(self, limit_up: list[dict], sector_flow: list[dict]) -> list[dict]:
        pool = []
        seen = set()
        for item in sorted(limit_up, key=lambda x: -int(x.get("consecutive_days", 1))):
            sym = item.get("symbol")
            if sym and sym not in seen and len(pool) < 8:
                seen.add(sym)
                pool.append({
                    "symbol": sym, "name": item.get("name"),
                    "consecutive_days": item.get("consecutive_days", 1),
                    "sector": item.get("sector"),
                    "reason": item.get("reason") or "涨停强势",
                    "source": "涨停梯队",
                })
        for s in sector_flow[:5]:
            if len(pool) >= 12:
                break
            leader = s.get("leader_symbol")
            name = s.get("sector_name", "")
            if not leader:
                continue
            if leader not in seen:
                seen.add(leader)
                pool.append({"symbol": leader, "name": name + "龙头",
                             "consecutive_days": 0, "sector": name,
                             "reason": f"板块净流入 {float(s.get('net_inflow', 0))/1e8:.1f}亿", "source": "板块资金"})
        return pool

    async def _enrich_stock_pool(self, pool: list[dict]) -> list[dict]:
        dsm = DataSourceManager(self.db)
        symbols = [p["symbol"] for p in pool if p.get("symbol")]
        if not symbols:
            return pool
        try:
            rt = await dsm.get_realtime(symbols)
        except Exception:
            rt = {}
        for p in pool:
            info = rt.get(p["symbol"], {})
            p["price"] = info.get("price", 0)
            p["change_pct"] = info.get("change_pct", 0)
            cd = p.get("consecutive_days", 0)
            source = p.get("source", "")
            if cd >= 3:
                p["performance"] = f"强势{cd}连板"
                p["suggestion"] = "高标关注，注意断板风险"
            elif cd >= 2:
                p["performance"] = f"{cd}连板晋级"
                p["suggestion"] = "关注封单强度"
            elif source == "涨停梯队":
                p["performance"] = "首板涨停"
                p["suggestion"] = "关注次日竞价"
            else:
                p["performance"] = "板块龙头"
                p["suggestion"] = "关注板块持续性"
        return pool

    def _to_markdown(self, d: date, summary, sector_flow, ladder, pool, reviews) -> str:
        lines = [f"# 复盘报告 {d}", ""]
        lines.append("## 市场概况")
        for idx in summary.get("indices", []):
            lines.append(f"- {idx.get('name')}: {idx.get('price')} ({idx.get('change_pct')}%)")
        lines.append(f"- 涨跌家数: {summary.get('distribution', {}).get('up_count', 0)}↑ / {summary.get('distribution', {}).get('down_count', 0)}↓")
        lines.append(f"- 涨停: {summary.get('limit_up_count', 0)}")
        lines.append("")
        lines.append("## 板块资金流")
        for s in sector_flow[:10]:
            lines.append(f"- {s.get('sector_name')}: 净流入 {float(s.get('net_inflow', 0)):.0f}")
        lines.append("")
        lines.append("## 涨停梯队")
        for k, v in ladder.get("ladder", {}).items():
            lines.append(f"- {k}连板: " + ", ".join(i.get("name", "") for i in v[:5]))
        lines.append("")
        lines.append("## 次日选股池")
        for p in pool[:12]:
            lines.append(f"- {p.get('symbol')} {p.get('name')}: {p.get('reason')}")
        lines.append("")
        for at, r in reviews.items():
            lines.append(f"## AI复盘 - {at}")
            lines.append(f"- {r.get('summary', '')}")
            lines.append("")
        return "\n".join(lines)

    async def get_latest(self) -> dict:
        rep = (await self.db.execute(select(ReplayReport).order_by(ReplayReport.date.desc()).limit(1))).scalars().first()

        def _is_trading_weekday(d) -> bool:
            return d.weekday() < 5

        today = date.today()
        if not rep:
            return {"status": "empty", "date": today.isoformat(),
                    "message": "尚无复盘报告，交易日 18:00 将自动生成，也可手动点击底部按钮生成"}

        if rep.date.isoformat() != today.isoformat() and _is_trading_weekday(today):
            # 新交易日刚开始（今日尚未生成），不展示旧复盘，提示可重新生成
            return {"status": "pending", "date": today.isoformat(), "latest_date": rep.date.isoformat(),
                    "message": f"今日({today.isoformat()})复盘尚未生成，交易日 18:00 自动复盘，也可现在手动生成",
                    "data": self._serialize(rep)}
        return {"status": "ready", "date": rep.date.isoformat(), "data": self._serialize(rep)}

    async def get_by_date(self, d: date) -> dict:
        rep = (await self.db.execute(select(ReplayReport).where(ReplayReport.date == d))).scalars().first()
        return self._serialize(rep) if rep else None

    async def get_history(self, limit: int = 30) -> list[dict]:
        rows = (await self.db.execute(select(ReplayReport).order_by(ReplayReport.date.desc()).limit(limit))).scalars().all()
        return [{"date": r.date.isoformat(), "id": r.id} for r in rows]

    @staticmethod
    def _serialize(rep) -> dict:
        return {
            "id": rep.id, "date": rep.date.isoformat(),
            "market_summary": rep.market_summary, "sector_flow": rep.sector_flow,
            "limit_analysis": rep.limit_analysis, "stock_pool": rep.stock_pool,
            "agent_reviews": rep.agent_reviews, "report_md": rep.report_md,
        }